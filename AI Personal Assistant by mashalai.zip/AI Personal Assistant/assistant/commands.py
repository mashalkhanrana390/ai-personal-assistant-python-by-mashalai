def process_command(command):
    command = command.lower()

    if command == "hello":
        return "Hello! How can I help you?"

    elif command == "how are you":
        return "I'm doing great!"

    elif command == "your name":
        return "I am your AI Personal Assistant."

    else:
        return "Sorry, I don't understand that command."