from datetime import datetime


print("==============================")
print("     AI PERSONAL ASSISTANT")
print("==============================")


def process_command(command):
    command = command.lower().strip()

    # Hello
    if "hello" in command:
        return "Hello! How can I help you?"

    # How are you
    elif "how are you" in command:
        return "I'm doing great!"

    # Name
    elif "your name" in command:
        return "I am your AI Personal Assistant."

    # Time
    elif "time" in command:
        current_time = datetime.now().strftime("%I:%M %p")
        return f"The current time is {current_time}"

    # Date
    elif "date" in command:
        current_date = datetime.now().strftime("%d %B %Y")
        return f"Today's date is {current_date}"

    # Unknown command
    else:
        return "Sorry, I don't understand that command."


def main():
    print("🤖 AI PERSONAL ASSISTANT STARTED.")
    print("Type 'exit' to stop.")

    while True:
        command = input("You: ")

        if command.lower().strip() == "exit":
            print("Assistant: Goodbye!")
            break

        response = process_command(command)
        print("Assistant:", response)


if __name__ == "__main__":
    main()
